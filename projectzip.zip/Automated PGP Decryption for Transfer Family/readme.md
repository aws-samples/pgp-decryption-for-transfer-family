# PGP Decryption for Transfer Family

## Project Requirements 
### Created by setupEnvironment.sh script
- IAM Managed Workflow Execution Role 
- IAM Lambda Execution Role 
- Custom Lambda Layer including required binary/python package. 
### Created Manually via AWS Console
- Transfer Family Server
- Transfer Family Managed Workflow
- S3 Bucket
- Lambda Function for PGP Decryption


## Step-by-Step Instructions to Create Requirements

### CloudShell - Automated Creation of IAM Roles and Lambda Layer
**** Since the GitHub Repo is currently private, I have removed the part where the user clones the GitHub repo into their Cloudshell environment ****
**** I have created these different directions where you can upload the IAM_Policies.zip to cloudshell, unzip it, and it'll work the same as if you cloned the GitHub repo ****
**** Since Windows does not play nicely with Linux, if you try to upload the shell script from Windows -> CloudShell, it will not run. For this reason, you will need to create a blank shell script, and paste in the contents of the script in order for it to work. End users will not have to do this once the GitHub repo is public, since they'll just be cloning the repo.****
- This script accomplishes the following: 
  - Downloads and builds GPG binary from source, as well as Python-GNUPG package, and publishes them to a Lambda layer. 
  - Creates the two required IAM execution roles, one for Lambda, one for Transfer Family managed workflow. 

#### CloudShell Directions
- Open up CloudShell within your AWS account. 
- Select "Actions" -> "Upload File"
- Upload the IAM_Policices.zip folder which contains all the required IAM_Policies
- Unzip the folder with this command: `unzip IAM_Policices.zip`
- Install nano to create and edit shell script: `sudo yum install nano -y`
- Create shell script: `nano setupEnvironment.sh`
- Paste the shell script into the setupEnvironment.sh file and save the file. `Ctrl + X, then press y, then press enter`
- Give the shell script executable permissions: `chmod +x setupEnvironment.sh`
- Run the script: `./setupEnvironment.sh`
- 


### Creating Transfer Family Server with Custom Identity Provider (OPTIONAL)
- NOTE: If you already have a Transfer Family server in place that you want to use, or if you don't want to use a custom identity provider, you can ignore this step. 
- However, this project does require that you have a Transfer Family server running within your AWS account, so if you don't currently have one, I'd recommend completing this step as it will create the Transfer Family server, custom identity provider, and all of the required IAM policies for you.  
- Refer to this link for detailed instructions on deploying a CloudFormation stack that will create a Transfer Family server, custom identity provider, and all the required IAM policies: [https://aws.amazon.com/blogs/storage/enable-password-authentication-for-aws-transfer-family-using-aws-secrets-manager-updated/](url)


### Creating Transfer Family Server
- If you don't want to deploy the custom Transfer Family identity provider via CloudFormation mentioned in the above step, and don't have a currently up and running Transfer Family server, please refer to this link for instructions on how to create a new Transfer Family server: https://docs.aws.amazon.com/transfer/latest/userguide/getting-started.html
- If you deployed the CloudFormation stack mentioned in the step above, you can ignore this step. 


### Creating the Lambda Function
- On the AWS Console, navigate to Lambda -> Functions
- Click "Create function"
- Select "Author from scratch"
- Name your Lambda function (Example: AutomatedPGPDecryption)
- Select "Python 3.8" as the Runtime
- Select "x86_64" as the Architecture
- Select "Change default execution role"
  - Select "Use an existing role"
  - Search "PGPDecryptionLambdaExecutionRole" and select it
- Click "Create Function"
- After creating the function, paste in the Python code from the lambdaSource.py file hosted on this GitHub.
- Click "Deploy" to save your changes

#### Attaching Layer to Lambda Function
- Scroll to the bottom of your Lambda function and select "Add a layer"
- Select "Custom layers"
- Choose "python-gnupg" as the layer
- Select whichever version is present and click "Add"


#### Editing Default Lambda Timeout
- Within your Lambda function console, select "Configuration" and then "General Configuration"
- Click "Edit"
- Change the timeout time from 3 seconds -> 15 seconds


### Creating an S3 Bucket (POSSIBLY OPTIONAL)
- NOTE: This step is only optional if you already have an S3 bucket configured that you'd like to use. 
- If not, you will need to follow these steps to create a new S3 bucket 
- Navigate to the S3 console within the AWS console
- Click "Create bucket"
- Name your bucket (Example: pgp-decrypted-files)
- Leave all options as default, unless you have specific requirements to do otherwise
- Scroll down to the bottom and select "Create bucket"



### Creating Transfer Family Managed Workflow
- Navigate to the Transfer Family console within the AWS console
- Select "Workflows"
- Select "Create Workflow"
- Provide a brief description of the workflow (Example: Automate PGP Decryption)
#### Nominal Steps
#### Step 1: Copy to Archive
- Under "Nominal steps", select "Add step"
  - Select "Copy file"
  - Name the step (Example: copyToArchive)
  - Select destination bucket (Example: "pgp-decrypted-files")
  - For Destination key prefix, insert the following: "Archive/${transfer:UserName}/" 
  - Select "Next" and then "Create step"
  
#### Step 2: Tag as Archived  
- Under "Nominal steps", select "Add step" 
  - Select "Tag file"
  - Name the step (Example: tagAsArchived)
  - For file location, select "Tag the file created from previous step"
  - For Key enter: "Status"
  - For Value enter: "Archived"
  - Click "Next" and the "Create step"

#### Step 3: PGP Decryption
- Under "Nominal steps", select "Add step"
  - Select "Custom file-processing step"
  - Name the step (Example: PGP_Decryption)
  - For file location, select "Apply custom processing to the original source file"
  - For target, select the Lambda function we created in earlier steps (Example: AutomatedPGPDecryption)
  - For timeout, leave as default (60 seconds)
  - Click "Next" and "Create step"

#### Step 4: Delete Originally Uploaded File
- Under "Nominal steps", select "Add step"
  - Select "Delete file"
  - Name the step (Example: Delete_Original_File)
  - For file location, select "Delete the original source file"
  - Click "Next" and "Create step"


#### Managed Workflow Exception Handlers

#### Step 1: Copy to Failed Prefix
- Under "Exception handlers - optional", select "Add step"
  - Select "Copy file"
  - Name the step (Example: copyToFailedPrefix)
  - Select destination bucket (Example: "pgp-decrypted-files")
  - For Destination key prefix, insert the following: "FailedDecryption/${transfer:UserName}/" 
  - Select "Next" and then "Create step"

#### Step 2: Tag as Failed  
- Under "Exception handlers - optional", select "Add step"
  - Select "Tag file"
  - Name the step (Example: tagAsFailed)
  - For file location, select "Tag the file created from previous step"
  - For Key enter: "Status"
  - For Value enter: "Failed Decryption"
  - Click "Next" and the "Create step"

#### Step 3: Delete Originally Uploaded File
- Under "Exception handlers - optional", select "Add step"
  - Select "Delete file"
  - Name the step (Example: Delete_Original_File)
  - For file location, select "Delete the original source file"
  - Click "Next" and "Create step"


#### Final Step for Managed Workflow Creation
- Select "Create Workflow"


### Attach Managed Workflow to Transfer Family Server
- On the Transfer Family console, select "Servers"
- Select your desired Transfer Family server
- Under "Additional details", select "Edit"
- Select the newly created Workflow (Example: Automate PGP Decryption)
- Select the newly created Managed workflow execution role (Example: PGPDecryptionManagedWorkflowRole)
- Select "Save"


### Adding Private Key to Secrets Manager
- On the AWS Console, navigate to Secrets Manager. 
- Select "Store a new secret"
- Select "Other type of secret"
- Select "Plaintext"
- Delete the `{"":""}` 
- Paste in your Private Key
- Select "Next"
- Name your secret: PGP_PrivateKey
- Select "Next"
- Leave all options as default, select "Next"
- Select "Store"



## Security

See [CONTRIBUTING](CONTRIBUTING.md#security-issue-notifications) for more information.

## License

This library is licensed under the MIT-0 License. See the LICENSE file.
